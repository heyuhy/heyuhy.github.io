For any question, please feel free to contact with me by hurenjun@buaa.edu.cn or renjun0hu@gmail.com.

-- data format
(a) each file corresponds to a graph;
(b) in the graph files, each line represents an edge in the graph and contains four numbers, i.e., source, targer, number 0 and edge weight.
(c) in the original setting, there are prizes on nodes and costs on edges if including the nodes and edges in a subgraph. Here we tranform original graphs with both node weights (prizes) and edge weights (costs) to graphs with only edge weights such that negative weights are the costs on edges and positive weights are indeed the prizes of nodes. It should be straightforward to derive the original graphs with the transformed graphs.  

-- for a subgraph G'(V', E') of a graph G(V, E): 
(a) GW = the cost of the edges in the G' + the prizes of the vertices not in G';
(b) NW = prizes of the vertices in G' - the cost of the edge in the G';
(c) the subgraph must be a subtree for optimality of NW;
(d) GW + NW = total_prize, thus maximizing NW is equivalent to minimizing GW.

-- results
# graph	total_prize	Optimal_GW	Optimal_NW
K100	161737	135511	26226
K100.1	149330	124108	25222
K100.10	162727	133567	29160
K100.2	243247	200262	42985
K100.3	144349	115953	28396
K100.4	117487	87498	29989
K100.5	145417	119078	26339
K100.6	159892	132886	27006
K100.7	211888	172457	39431
K100.8	268634	210869	57765
K100.9	146452	122917	23535
K200	368983	329211	39772
K400	398802	350093	48709
K400.1	522639	490771	31868
K400.10	448964	394191	54773
K400.2	518443	477073	41370
K400.3	444216	401881	42335
K400.4	433079	389451	43628
K400.5	572219	519526	52693
K400.6	404068	374849	29219
K400.7	543106	474466	68640
K400.8	441562	418614	22948
K400.9	425333	383105	42228

P100	2114127	803300	1310827
P100.1	1533544	926238	607306
P100.2	948871	401641	547230
P100.3	1334967	659644	675323
P100.4	1643518	827419	816099
P200	2351264	1317874	1033390
P400	4351775	2459904	1891871
P400.1	6054291	2808440	3245851
P400.2	5231801	2518577	2713224
P400.3	5125476	2951725	2173751
P400.4	4962336	2817438	2144898

steinc1-A	27	18	9
steinc1-B	274	85	189
steinc10-A	1248	859	389
steinc10-B	12533	1069	11464
steinc11-A	27	18	9
steinc11-B	274	32	242
steinc12-A	59	38	21
steinc12-B	604	46	558
steinc13-A	439	236	203
steinc13-B	4463	258	4205
steinc14-A	648	293	355
steinc14-B	6566	318	6248
steinc15-A	1248	501	747
steinc15-B	12533	551	11982
steinc16-A	27	11	16
steinc16-B	274	11	263
steinc17-A	59	18	41
steinc17-B	604	18	586
steinc18-A	439	111	328
steinc18-B	4463	113	4350
steinc19-A	648	146	502
steinc19-B	6566	146	6420
steinc2-A	59	50	9
steinc2-B	604	141	463
steinc20-A	1248	266	982
steinc20-B	12533	267	12266
steinc3-A	439	414	25
steinc3-B	4463	737	3726
steinc4-A	648	618	30
steinc4-B	6566	1063	5503
steinc5-A	1248	1080	168
steinc5-B	12533	1528	11005
steinc6-A	27	18	9
steinc6-B	274	55	219
steinc7-A	59	50	9
steinc7-B	604	102	502
steinc8-A	439	361	78
steinc8-B	4463	500	3963
steinc9-A	648	533	115
steinc9-B	6566	694	5872

steind1-A	27	18	9
steind1-B	274	106	168
steind10-A	2490	1671	819
steind10-B	24951	2079	22872
steind11-A	27	18	9
steind11-B	274	29	245
steind12-A	59	42	17
steind12-B	604	42	562
steind13-A	847	445	402
steind13-B	8514	486	8028
steind14-A	1248	602	646
steind14-B	12533	665	11868
steind15-A	2490	1042	1448
steind15-B	24951	1108	23843
steind16-A	27	13	14
steind16-B	274	13	261
steind17-A	59	23	36
steind17-B	604	23	581
steind18-A	847	218	629
steind18-B	8514	223	8291
steind19-A	1248	306	942
steind19-B	12533	310	12223
steind2-A	59	50	9
steind2-B	604	218	386
steind20-A	2490	536	1954
steind20-B	24951	537	24414
steind3-A	847	807	40
steind3-B	8514	1509	7005
steind4-A	1248	1203	45
steind4-B	12533	1881	10652
steind5-A	2490	2157	333
steind5-B	24951	3135	21816
steind6-A	27	18	9
steind6-B	274	67	207
steind7-A	59	50	9
steind7-B	604	103	501
steind8-A	847	755	92
steind8-B	8514	1036	7478
steind9-A	1248	1070	178
steind9-B	12533	1420	11113
